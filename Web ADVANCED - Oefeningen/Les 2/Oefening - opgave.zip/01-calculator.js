﻿/*
 * Maak een "calculator" object met daarin de volgende functies:
 *   - history: bijhouden van de input (array)
 *   - addNumber: nummer toevoegen aan de history
 *   - addOperator: operator (+, -, /, *) toevoegen aan de history
 *   - showHistory: history array weergeven in de HTML
 *   - clear: history leegmaken
 *   - calculate: berekening uit de history uitvoeren
 */